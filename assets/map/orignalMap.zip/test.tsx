<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="test" tilewidth="16" tileheight="16" tilecount="1440" columns="40">
 <image source="BaseMain.png" width="640" height="576"/>
 <tile id="40">
  <animation>
   <frame tileid="40" duration="150"/>
   <frame tileid="41" duration="150"/>
   <frame tileid="42" duration="150"/>
   <frame tileid="43" duration="150"/>
  </animation>
 </tile>
 <tile id="80">
  <animation>
   <frame tileid="80" duration="150"/>
   <frame tileid="81" duration="150"/>
   <frame tileid="82" duration="150"/>
   <frame tileid="83" duration="150"/>
  </animation>
 </tile>
 <tile id="383">
  <animation>
   <frame tileid="383" duration="150"/>
   <frame tileid="386" duration="150"/>
   <frame tileid="389" duration="150"/>
  </animation>
 </tile>
</tileset>
